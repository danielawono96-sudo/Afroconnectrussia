# AfroConnect Russia — Structure du projet

```
afroconnect-russia/
│
├── apps/
│   ├── web/                          # Next.js 14 (Web App)
│   │   ├── app/
│   │   │   ├── (auth)/
│   │   │   │   ├── login/page.tsx
│   │   │   │   ├── register/page.tsx
│   │   │   │   └── layout.tsx
│   │   │   ├── (main)/
│   │   │   │   ├── feed/page.tsx
│   │   │   │   ├── business/page.tsx
│   │   │   │   ├── connect/page.tsx
│   │   │   │   ├── community/page.tsx
│   │   │   │   ├── messages/page.tsx
│   │   │   │   ├── profile/[id]/page.tsx
│   │   │   │   └── layout.tsx
│   │   │   ├── api/
│   │   │   │   └── [...proxy]/route.ts
│   │   │   ├── layout.tsx
│   │   │   └── page.tsx             # Landing page
│   │   ├── components/
│   │   │   ├── ui/                  # Design system components
│   │   │   ├── feed/
│   │   │   ├── profile/
│   │   │   ├── messaging/
│   │   │   └── layout/
│   │   ├── lib/
│   │   │   ├── api.ts
│   │   │   ├── auth.ts
│   │   │   └── i18n.ts
│   │   ├── public/
│   │   ├── next.config.js
│   │   ├── tailwind.config.js
│   │   └── package.json
│   │
│   ├── mobile/                       # React Native (iOS + Android)
│   │   ├── src/
│   │   │   ├── screens/
│   │   │   │   ├── Auth/
│   │   │   │   ├── Feed/
│   │   │   │   ├── Business/
│   │   │   │   ├── Connect/
│   │   │   │   ├── Community/
│   │   │   │   ├── Messages/
│   │   │   │   └── Profile/
│   │   │   ├── components/
│   │   │   ├── navigation/
│   │   │   ├── store/               # Zustand
│   │   │   ├── hooks/
│   │   │   └── utils/
│   │   ├── app.json
│   │   └── package.json
│   │
│   └── admin/                        # Dashboard administrateur
│       ├── app/
│       │   ├── users/page.tsx
│       │   ├── reports/page.tsx
│       │   ├── events/page.tsx
│       │   └── analytics/page.tsx
│       └── package.json
│
├── packages/
│   ├── ui/                           # Design System partagé
│   │   ├── src/
│   │   │   ├── tokens/
│   │   │   │   ├── colors.ts        # Palette Or/Noir/Vert
│   │   │   │   ├── typography.ts
│   │   │   │   ├── spacing.ts
│   │   │   │   ├── shadows.ts
│   │   │   │   └── motion.ts
│   │   │   ├── components/
│   │   │   │   ├── Button/
│   │   │   │   ├── Input/
│   │   │   │   ├── Badge/
│   │   │   │   ├── Avatar/
│   │   │   │   ├── Card/
│   │   │   │   ├── Modal/
│   │   │   │   └── UserCard/
│   │   │   └── index.ts
│   │   └── package.json
│   │
│   ├── i18n/                         # Internationalisation (11 langues)
│   │   ├── locales/
│   │   │   ├── fr/common.json
│   │   │   ├── en/common.json
│   │   │   ├── ru/common.json
│   │   │   ├── ar/common.json
│   │   │   ├── sw/common.json       # Swahili
│   │   │   ├── ha/common.json       # Haoussa
│   │   │   ├── am/common.json       # Amharique
│   │   │   ├── yo/common.json       # Yoruba
│   │   │   ├── ig/common.json       # Igbo
│   │   │   ├── wo/common.json       # Wolof
│   │   │   └── pt/common.json
│   │   └── package.json
│   │
│   ├── api-client/                   # SDK client API
│   │   ├── src/
│   │   │   ├── users.ts
│   │   │   ├── matching.ts
│   │   │   ├── messaging.ts
│   │   │   ├── events.ts
│   │   │   └── business.ts
│   │   └── package.json
│   │
│   └── shared/                       # Types & utilitaires communs
│       ├── src/
│       │   ├── types/
│       │   │   ├── user.ts
│       │   │   ├── message.ts
│       │   │   ├── event.ts
│       │   │   └── business.ts
│       │   └── utils/
│       └── package.json
│
├── backend/
│   ├── src/
│   │   ├── config/
│   │   │   ├── database.ts          # PostgreSQL + pgvector
│   │   │   ├── redis.ts
│   │   │   └── env.ts
│   │   ├── middleware/
│   │   │   ├── auth.middleware.ts
│   │   │   ├── rateLimit.middleware.ts
│   │   │   ├── cors.middleware.ts
│   │   │   └── validation.middleware.ts
│   │   ├── modules/
│   │   │   ├── auth/
│   │   │   │   ├── auth.controller.ts
│   │   │   │   ├── auth.service.ts
│   │   │   │   ├── auth.routes.ts
│   │   │   │   └── auth.schema.ts
│   │   │   ├── users/
│   │   │   │   ├── users.controller.ts
│   │   │   │   ├── users.service.ts
│   │   │   │   ├── users.routes.ts
│   │   │   │   └── users.schema.ts
│   │   │   ├── matching/
│   │   │   │   ├── matching.controller.ts
│   │   │   │   ├── matching.service.ts
│   │   │   │   └── matching.algorithm.ts  # pgvector + ML
│   │   │   ├── messaging/
│   │   │   │   ├── messaging.controller.ts
│   │   │   │   ├── messaging.service.ts
│   │   │   │   └── messaging.gateway.ts   # Socket.io
│   │   │   ├── events/
│   │   │   │   ├── events.controller.ts
│   │   │   │   └── events.service.ts
│   │   │   └── business/
│   │   │       ├── business.controller.ts
│   │   │       └── business.service.ts
│   │   ├── database/
│   │   │   ├── migrations/
│   │   │   │   ├── 001_create_users.sql
│   │   │   │   ├── 002_create_profiles.sql
│   │   │   │   ├── 003_create_messages.sql
│   │   │   │   ├── 004_create_events.sql
│   │   │   │   └── 005_create_matches.sql
│   │   │   └── seeds/
│   │   └── app.ts                   # Entry point Express
│   ├── tests/
│   ├── .env.example
│   ├── Dockerfile
│   └── package.json
│
├── agents/
│   ├── marketing/
│   │   ├── marketingBot.ts          # Agent contenu Claude Sonnet
│   │   ├── templates/               # Templates par plateforme
│   │   └── tests/
│   ├── investor/
│   │   ├── investorBot.ts           # Agent recherche investisseurs
│   │   ├── pitchGenerator.ts
│   │   └── tests/
│   ├── translator/
│   │   ├── translatorBot.ts         # DeepL + Claude fallback
│   │   └── tests/
│   └── matching-ai/
│       ├── matchingAI.ts            # Recommandations intelligentes
│       ├── embeddings.ts            # Génération embeddings
│       └── tests/
│
├── .github/
│   └── workflows/
│       ├── ci.yml                   # Tests + lint à chaque PR
│       ├── deploy-frontend.yml      # Deploy Vercel auto
│       └── deploy-backend.yml       # Deploy Railway auto
│
├── docs/
│   ├── DESIGN_SYSTEM.md
│   ├── API_REFERENCE.md
│   ├── CONTRIBUTING.md
│   └── SECURITY.md
│
├── docker-compose.yml               # Dev local complet
├── turbo.json                       # Turborepo monorepo config
├── package.json                     # Root workspace
└── README.md
```
