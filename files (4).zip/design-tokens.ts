/**
 * AfroConnect Russia — Design Tokens officiels
 * Phase 0 · Version 1.0.0
 * CEO: Ngono Awono Daniel Junior
 */

// ── PALETTE ────────────────────────────────────────────────
export const colors = {
  // Or Premium (Primaire)
  gold: {
    light:   '#F0D060',
    DEFAULT: '#D4AF37',
    dark:    '#8B7020',
    bg:      '#D4AF3710',
    border:  '#D4AF3733',
  },
  // Noir Absolu
  noir: {
    DEFAULT: '#0A0A0A',
    surface: '#1A1A1A',
    muted:   '#2A2A2A',
  },
  // Blanc Pur
  blanc: {
    DEFAULT: '#FAFAFA',
    muted:   '#F0EFED',
  },
  // Vert Afrique (Secondaire)
  vert: {
    light:   '#40A074',
    DEFAULT: '#2D6A4F',
    dark:    '#1A4030',
    bg:      '#2D6A4F12',
    border:  '#2D6A4F44',
  },
  // Sémantique
  success:  '#2D6A4F',
  warning:  '#D4AF37',
  error:    '#C0392B',
  info:     '#2980B9',
} as const;

// ── TYPOGRAPHIE ────────────────────────────────────────────
export const typography = {
  fonts: {
    display: '"Playfair Display", Georgia, serif',
    body:    '"Inter", system-ui, sans-serif',
    mono:    '"Fira Code", "Courier New", monospace',
  },
  sizes: {
    xs:   '11px',
    sm:   '12px',
    base: '14px',
    md:   '15px',
    lg:   '18px',
    xl:   '22px',
    h1:   '28px',
    h1xl: '40px',
    hero: '56px',
  },
  weights: {
    light:   300,
    regular: 400,
    medium:  500,
    semibold:600,
    bold:    700,
  },
  lineHeights: {
    tight:   1.2,
    snug:    1.35,
    normal:  1.6,
    relaxed: 1.75,
  },
  tracking: {
    tight:  '-0.02em',
    normal:  '0',
    wide:    '0.05em',
    wider:   '0.08em',
    widest:  '0.12em',
  },
} as const;

// ── ESPACEMENT ─────────────────────────────────────────────
export const spacing = {
  1:  '4px',
  2:  '8px',
  3:  '12px',
  4:  '16px',
  5:  '20px',
  6:  '24px',
  8:  '32px',
  10: '40px',
  12: '48px',
  16: '64px',
  20: '80px',
  24: '96px',
} as const;

// ── BORDER RADIUS ──────────────────────────────────────────
export const radius = {
  sm:   '4px',
  md:   '8px',
  lg:   '12px',
  xl:   '20px',
  xxl:  '28px',
  pill: '9999px',
  full: '50%',
} as const;

// ── OMBRES ─────────────────────────────────────────────────
export const shadows = {
  0:    'none',
  sm:   '0 1px 4px 0 rgba(10,10,10,0.08)',
  md:   '0 4px 16px 0 rgba(10,10,10,0.10)',
  lg:   '0 8px 32px 0 rgba(10,10,10,0.12)',
  gold: '0 8px 32px 0 rgba(212,175,55,0.18)',
  vert: '0 4px 20px 0 rgba(45,106,79,0.15)',
} as const;

// ── MOTION ─────────────────────────────────────────────────
export const motion = {
  durations: {
    micro:    '150ms',
    standard: '250ms',
    page:     '400ms',
    slow:     '600ms',
  },
  easings: {
    standard:  'cubic-bezier(0.4, 0, 0.2, 1)',
    decelerate:'cubic-bezier(0, 0, 0.2, 1)',
    accelerate:'cubic-bezier(0.4, 0, 1, 1)',
    spring:    'cubic-bezier(0.34, 1.56, 0.64, 1)',
  },
  spring: {
    stiffness: 300,
    damping:   24,
    mass:      1,
  },
} as const;

// ── BREAKPOINTS ────────────────────────────────────────────
export const breakpoints = {
  sm:  '640px',
  md:  '768px',
  lg:  '1024px',
  xl:  '1280px',
  xxl: '1536px',
} as const;

// ── Z-INDEX ────────────────────────────────────────────────
export const zIndex = {
  base:    0,
  raised:  10,
  dropdown:100,
  sticky:  200,
  overlay: 300,
  modal:   400,
  toast:   500,
} as const;

// ── EXPORT GLOBAL ──────────────────────────────────────────
export const tokens = {
  colors,
  typography,
  spacing,
  radius,
  shadows,
  motion,
  breakpoints,
  zIndex,
} as const;

export type Tokens = typeof tokens;
export default tokens;
