/**
 * AfroConnect Russia — Tailwind Config
 * Basé sur les Design Tokens officiels
 */
const { colors, typography, spacing, radius, shadows } = require('./design-tokens');

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './apps/**/*.{js,ts,jsx,tsx}',
    './packages/ui/**/*.{js,ts,jsx,tsx}',
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        gold:  colors.gold,
        noir:  colors.noir,
        blanc: colors.blanc,
        vert:  colors.vert,
      },
      fontFamily: {
        display: ['"Playfair Display"', 'Georgia', 'serif'],
        body:    ['"Inter"', 'system-ui', 'sans-serif'],
        mono:    ['"Fira Code"', 'monospace'],
      },
      borderRadius: {
        sm:   '4px',
        md:   '8px',
        lg:   '12px',
        xl:   '20px',
        pill: '9999px',
      },
      boxShadow: {
        sm:   '0 1px 4px 0 rgba(10,10,10,0.08)',
        md:   '0 4px 16px 0 rgba(10,10,10,0.10)',
        gold: '0 8px 32px 0 rgba(212,175,55,0.18)',
        vert: '0 4px 20px 0 rgba(45,106,79,0.15)',
      },
      animation: {
        'fade-in':    'fadeIn 250ms ease-out',
        'slide-up':   'slideUp 400ms cubic-bezier(0.4, 0, 0.2, 1)',
        'spring-in':  'springIn 500ms cubic-bezier(0.34, 1.56, 0.64, 1)',
      },
      keyframes: {
        fadeIn:   { from: { opacity: 0 }, to: { opacity: 1 } },
        slideUp:  { from: { transform: 'translateY(16px)', opacity: 0 }, to: { transform: 'translateY(0)', opacity: 1 } },
        springIn: { from: { transform: 'scale(0.9)', opacity: 0 }, to: { transform: 'scale(1)', opacity: 1 } },
      },
    },
  },
  plugins: [],
};
